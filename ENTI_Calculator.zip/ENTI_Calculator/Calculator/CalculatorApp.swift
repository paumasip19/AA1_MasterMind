//
//  CalculatorApp.swift
//  Calculator
//
//  Created by Guillermo Fernandez on 24/02/2021.
//

import SwiftUI

@main
struct CalculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
